﻿namespace Stations.Models
{
    public enum TripStatus
    {
        OnTime,
        Delayed,
        Early
    }
}