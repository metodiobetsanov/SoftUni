﻿namespace Stations.Models
{
    public enum CardType
    {
        Normal, 
        Pupil,
        Student,
        Elder,
        Debilitated
    }
}
