namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=MSI\SQLEXPRESS;Database=Stations;Trusted_Connection=True";
	}
}