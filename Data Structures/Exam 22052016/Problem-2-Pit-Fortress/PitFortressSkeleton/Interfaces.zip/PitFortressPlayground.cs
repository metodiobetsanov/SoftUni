﻿public class PitFortressPlayground
{
    public static void Main()
    {
    }
}
