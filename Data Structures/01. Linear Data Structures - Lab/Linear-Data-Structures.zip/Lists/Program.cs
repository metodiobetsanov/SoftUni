﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        ArrayList<int> list = new ArrayList<int>();
        list.Add(10);

        Console.WriteLine();
    }
}
