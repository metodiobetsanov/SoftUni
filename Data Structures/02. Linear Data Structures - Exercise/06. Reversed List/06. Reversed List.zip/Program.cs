﻿using System;
using System.Linq;

namespace _06._Reversed_List
{
    class Program
    {
        static void Main()
        {
            
        }
    }
}
