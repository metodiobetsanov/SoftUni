﻿public enum SubmissionType
{
    CSharpCode,
    JavaCode,
    JavaScriptCode,
    PhpCode
}
