﻿namespace DungeonsAndCodeWizards.Models.Bags
{
    public class Backpack : Bag
    {
        public Backpack()
            : base()
        {
        }
    }
}