﻿
namespace Stations.Models.Enums
{
    public enum TripStatus
    {
        OnTime,
        Delayed,
        Early
    }
}