﻿namespace Stations.Models.Enums
{
    public enum CardType
    {
        Normal, 
        Pupil,
        Student,
        Elder,
        Debilitated
    }
}
