namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-LM5G6CJ\SQLEXPRESS;Database=Stations;Trusted_Connection=True";
	}
}